// モジュールを使うテスト

var tasizan2 = require('./tasizan2.js').tasizan2;
var tasizan3 = require('./tasizan2.js').tasizan3;

console.log(tasizan2(3, 5));
console.log(tasizan3(3, 5, 7));

