// 足し算の機能を持ったモジュール

module.exports = function (a, b) {
  return a + b;
};


