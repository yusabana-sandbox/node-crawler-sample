// tasizan モジュールの利用例

// モジュールの取り込み
var tasizan = require('./tasizan.js');

// モジュールの機能を利用する
console.log(tasizan(4, 5));
console.log(tasizan(1, 3));

