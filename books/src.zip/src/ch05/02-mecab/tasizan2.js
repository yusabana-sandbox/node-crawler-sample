// 複数の足し算の機能を持ったモジュール

module.exports.tasizan2 = function (a, b) {
  return a + b;
};

module.exports.tasizan3 = function (a, b, c) {
  return a + b + c;
};

